This project was pretty simple in implimentation.

The bitdisp will display the ascii coded binary digits of an input.

The bitrans will transpostion the bits according to a key file.

I had issues getting the bitrans to function right, I think they are fixed as of now. 